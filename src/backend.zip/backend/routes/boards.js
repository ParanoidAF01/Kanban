const express = require('express');
const { Board, User, Column, Card, Activity, sequelize } = require('../models');
const { authenticate, checkBoardPermission } = require('../middleware/auth');
const { validate, schemas } = require('../middleware/validation');
const { asyncHandler, NotFoundError, ForbiddenError, ConflictError } = require('../middleware/errorHandler');

const router = express.Router();

// Get all boards for current user
router.get('/',
  authenticate,
  validate(schemas.pagination, 'query'),
  asyncHandler(async (req, res) => {
    const { page, limit, sortBy, sortOrder } = req.query;
    const userId = req.user.id;
    const offset = (page - 1) * limit;

    // Use raw query to get boards with membership info
    const results = await sequelize.query(`
      SELECT 
        b.*,
        bm.role,
        bm.permissions,
        bm.joinedAt
      FROM boards b
      INNER JOIN board_members bm ON b.id = bm.boardId
      WHERE bm.userId = :userId AND bm.isActive = true
      ORDER BY b.${sortBy} ${sortOrder}
      LIMIT :limit OFFSET :offset
    `, {
      replacements: { userId, limit: parseInt(limit), offset: parseInt(offset) },
      type: sequelize.QueryTypes.SELECT
    });

    // Get total count
    const countResult = await sequelize.query(`
      SELECT COUNT(*) as count
      FROM boards b
      INNER JOIN board_members bm ON b.id = bm.boardId
      WHERE bm.userId = :userId AND bm.isActive = true
    `, {
      replacements: { userId },
      type: sequelize.QueryTypes.SELECT
    });
    const total = countResult[0].count;

    // Get columns for each board
    const boardsWithColumns = await Promise.all((results || []).map(async (board) => {
      const columns = await Column.findAll({
        where: { boardId: board.id },
        attributes: ['id', 'name', 'position', 'color'],
        order: [['position', 'ASC']]
      });

      return {
        ...board,
        Columns: columns,
        membership: {
          role: board.role,
          permissions: JSON.parse(board.permissions),
          joinedAt: board.joinedAt
        }
      };
    }));

    res.json({
      success: true,
      data: {
        boards: boardsWithColumns,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: total,
          pages: Math.ceil(total / limit)
        }
      }
    });
  })
);

// Create new board
router.post('/',
  authenticate,
  validate(schemas.createBoard),
  asyncHandler(async (req, res) => {
    const userId = req.user.id;
    const boardData = req.body;

    // Create board
    const board = await Board.create({
      ...boardData,
      ownerId: userId,
      position: 0
    });

    // Add owner as board member using raw query
    await sequelize.query(`
      INSERT INTO board_members (id, userId, boardId, role, permissions, joinedAt, isActive, createdAt, updatedAt)
      VALUES (:id, :userId, :boardId, :role, :permissions, :joinedAt, :isActive, :createdAt, :updatedAt)
    `, {
      replacements: {
        id: require('crypto').randomUUID(),
        userId,
        boardId: board.id,
        role: 'owner',
        permissions: JSON.stringify({
          canEditBoard: true,
          canDeleteBoard: true,
          canInviteMembers: true,
          canRemoveMembers: true,
          canCreateColumns: true,
          canEditColumns: true,
          canDeleteColumns: true,
          canCreateCards: true,
          canEditCards: true,
          canDeleteCards: true,
          canMoveCards: true,
          canAssignCards: true,
          canComment: true,
          canVote: true
        }),
        joinedAt: new Date(),
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    });

    res.status(201).json({
      success: true,
      message: 'Board created successfully',
      data: { board }
    });
  })
);

module.exports = router;
