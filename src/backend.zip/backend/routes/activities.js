const express = require('express');
const router = express.Router();

// Placeholder routes
router.get('/', (req, res) => {
  res.json({ success: true, message: 'Activities endpoint - coming soon' });
});

module.exports = router;
