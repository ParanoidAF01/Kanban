const jwt = require('jsonwebtoken');
const { User, Board, BoardMember } = require('../models');

// JWT utilities
const generateTokens = (user) => {
  const payload = {
    id: user.id,
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName
  };

  const accessToken = jwt.sign(payload, process.env.JWT_SECRET || 'fallback-secret', {
    expiresIn: process.env.JWT_ACCESS_EXPIRES_IN || '15m'
  });

  const refreshToken = jwt.sign(
    { id: user.id, type: 'refresh' },
    process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET || 'fallback-secret',
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d' }
  );

  return { accessToken, refreshToken };
};

const verifyToken = (token, secret = process.env.JWT_SECRET || 'fallback-secret') => {
  try {
    return jwt.verify(token, secret);
  } catch (error) {
    throw new Error('Invalid token');
  }
};

// Authentication middleware
const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        message: 'Access token required'
      });
    }

    const token = authHeader.substring(7);
    const decoded = verifyToken(token);

    // Get user from database
    const user = await User.findByPk(decoded.id, {
      attributes: { exclude: ['password'] }
    });

    if (!user || !user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'User not found or inactive'
      });
    }

    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired token'
    });
  }
};

// Optional authentication (doesn't fail if no token)
const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      req.user = null;
      return next();
    }

    const token = authHeader.substring(7);
    const decoded = verifyToken(token);

    const user = await User.findByPk(decoded.id, {
      attributes: { exclude: ['password'] }
    });

    req.user = user && user.isActive ? user : null;
    next();
  } catch (error) {
    req.user = null;
    next();
  }
};

// Board permission middleware
const checkBoardPermission = (permission) => {
  return async (req, res, next) => {
    try {
      const { boardId } = req.params;
      const userId = req.user.id;

      // Get board with members
      const board = await Board.findByPk(boardId, {
        include: [{
          model: BoardMember,
          where: { userId, isActive: true },
          required: false
        }]
      });

      if (!board) {
        return res.status(404).json({
          success: false,
          message: 'Board not found'
        });
      }

      const membership = board.BoardMembers[0];
      
      // Check if user is owner
      if (membership && membership.role === 'owner') {
        req.boardMembership = membership;
        return next();
      }

      // Check specific permission
      if (!membership || !membership.permissions[permission]) {
        return res.status(403).json({
          success: false,
          message: `Insufficient permissions: ${permission} required`
        });
      }

      req.boardMembership = membership;
      next();
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: 'Error checking board permissions'
      });
    }
  };
};

// Rate limiting for auth endpoints
const authRateLimit = (req, res, next) => {
  // Simple in-memory rate limiting (in production, use Redis)
  const key = `auth_${req.ip}`;
  const now = Date.now();
  const windowMs = 15 * 60 * 1000; // 15 minutes
  const maxAttempts = 50; // Increased for testing

  if (!global.rateLimitStore) {
    global.rateLimitStore = new Map();
  }

  const attempts = global.rateLimitStore.get(key) || [];
  const recentAttempts = attempts.filter(time => now - time < windowMs);

  if (recentAttempts.length >= maxAttempts) {
    return res.status(429).json({
      success: false,
      message: 'Too many authentication attempts. Please try again later.'
    });
  }

  recentAttempts.push(now);
  global.rateLimitStore.set(key, recentAttempts);

  next();
};

module.exports = {
  generateTokens,
  verifyToken,
  authenticate,
  optionalAuth,
  checkBoardPermission,
  authRateLimit
};
